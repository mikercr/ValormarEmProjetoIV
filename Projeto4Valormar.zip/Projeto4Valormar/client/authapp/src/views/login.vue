<template>
  <div class="login">
    <login />
  </div>
</template>
<script>
import login from "@/components/auth/login";
export default {
  components: {
    login
  }
};
</script>

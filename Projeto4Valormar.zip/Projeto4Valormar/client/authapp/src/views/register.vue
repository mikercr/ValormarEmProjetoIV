<template>
  <div class="register">
    <register />
  </div>
</template>
<script>
import register from "@/components/auth/register";
export default {
  components: {
    register
  }
};
</script>
